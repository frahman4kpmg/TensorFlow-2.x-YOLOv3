# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['deep_sort', 'mnist', 'tools', 'yolov3']

package_data = \
{'': ['*'], 'mnist': ['mnist/*']}

install_requires = \
['opencv-python>=4.5.5,<5.0.0',
 'scipy>=1.8.0,<2.0.0',
 'seaborn>=0.11.2,<0.12.0',
 'tensorflow-gpu>=2.8.0,<3.0.0',
 'tensorflow>=2.8.0,<3.0.0',
 'tqdm>=4.64.0,<5.0.0']

setup_kwargs = {
    'name': 'yolov3',
    'version': '0.1.0',
    'description': 'YOLOv3',
    'long_description': None,
    'author': 'Farhan Rahman',
    'author_email': 'frahman4@kpmg.com.au',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
